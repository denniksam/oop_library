package step.java.library;

public interface Printable {
    void print() ;
}
