package step.java.library;

public class Hologram
        extends Literature {

    public Hologram( String title ) {
        super.setTitle( title ) ;
    }
}
